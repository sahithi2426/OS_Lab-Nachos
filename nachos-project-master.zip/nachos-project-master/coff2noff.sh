#!/bin/bash
set -e

cd coff2noff
make
